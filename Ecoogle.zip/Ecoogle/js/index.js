document.addEventListener('DOMContentLoaded', function() {
    var searchForm = document.getElementById('searchForm');
    var searchResultsElement = document.getElementById('searchResults');
    var navigation = document.getElementById('navigation');

    // Função para buscar resultados gerais (sites, imagens, vídeos, notícias, livros)
    function fetchSearchResults(searchTerm, type) {
        var myHeaders = new Headers();
        myHeaders.append("X-API-KEY", "senhaAPI");
        myHeaders.append("Content-Type", "application/json");

        var endpoint = "https://google.serper.dev/search";
        if (type === 'images') {
            endpoint = "https://google.serper.dev/images";
        } else if (type === 'videos') {
            endpoint = "https://google.serper.dev/videos";
        } else if (type === 'news') {
            endpoint = "https://google.serper.dev/news";
        } else if (type === 'shopping') {
            endpoint = "https://google.serper.dev/shopping";
        } else if (type === 'places'){
            endpoint = "https://google.serper.dev/places";
        } else if (type === 'scholar'){
            endpoint = "https://google.serper.dev/scholar";
        } else if (type === 'patents'){
            endpoint = "https://google.serper.dev/patents";
        } else if(type === 'maps'){
            endpoint = "https://google.serper.dev/maps";
        }

        var raw = JSON.stringify({
            "q": searchTerm,
            "gl": "br",
            "hl": "pt",
            "engine": "google",
            "num": 30
        });

        var requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: raw,
            redirect: 'follow'
        };

        fetch(endpoint, requestOptions)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Erro ao buscar os resultados da API.');
                }
                return response.json();
            })
            .then(result => {
                if (type === 'images') {
                    displayImageResults(result);
                } else if (type === 'videos') {
                    displayVideoResults(result);
                } else if (type === 'news') {
                    displayNewsResults(result);
                } else if (type === 'shopping') {
                    displayBookResults(result);
                } else if(type === 'places'){
                    displayPlaces(result);
                } else if (type === 'scholar'){
                    displayScholar(result);
                } else if (type === 'patents'){
                    displayPatents(result);
                } else if (type === 'maps'){
                    displayMaps(result);
                }
                else {
                    displaySearchResults(result);
                }
            })
            .catch(error => {
                console.log('Ocorreu um erro ao processar a sua busca.');
            });
    }

    // Função para exibir resultados de vídeos
    function displayVideoResults(data) {
        searchResultsElement.innerHTML = '';

        // Mostra resultados de vídeos
        if (data.videos && data.videos.length > 0) {
            var videos = data.videos;
            var videoContainer = document.createElement('div');
            videoContainer.classList.add('video-container');

            videos.forEach(video => {
                var videoElement = document.createElement('div');
                videoElement.classList.add('video-item');
                videoElement.innerHTML = `
                    <h3>${video.title}</h3>
                    <div class="imgsinp">
                    <iframe width="150" height="100" src="${video.imageUrl}" frameborder="0" allowfullscreen></iframe>
                    <p>${video.snippet}</p>
                    </div>
                    <a href="${video.link}" target="_blank">Assistir no ${video.source}</a><br><br>
                `;
                videoContainer.appendChild(videoElement);
            });

            searchResultsElement.appendChild(videoContainer);
        } else {
            var noResultsMessage = document.createElement('p');
            noResultsMessage.textContent = 'Nenhum resultado encontrado para vídeos.';
            searchResultsElement.appendChild(noResultsMessage);
        }
    }

    // Event listener para o formulário de busca principal
    searchForm.addEventListener('submit', function(event) {
        event.preventDefault();
        var searchTerm = document.getElementById('searchInput').value.trim();

        if (searchTerm !== '') {
            fetchSearchResults(searchTerm, 'web'); // 'web' para pesquisa de sites
        } else {
            alert('Por favor, digite um termo de busca.');
        }
    });

    // Event listener para o formulário de busca de imagens
    document.getElementById('searchImage').addEventListener('submit', function(event) {
        event.preventDefault();
        var searchTerm = document.getElementById('searchInput').value.trim();

        if (searchTerm !== '') {
            fetchSearchResults(searchTerm, 'images'); // 'images' para pesquisa de imagens
        } else {
            alert('Por favor, digite um termo de busca para imagens.');
        }
    });

    // Event listener para o formulário de busca de vídeos
    document.getElementById('searchVideo').addEventListener('submit', function(event) {
        event.preventDefault();
        var searchTerm = document.getElementById('searchInput').value.trim();

        if (searchTerm !== '') {
            fetchSearchResults(searchTerm, 'videos'); // 'videos' para pesquisa de vídeos
        } else {
            alert('Por favor, digite um termo de busca para vídeos.');
        }
    });

    // Event listener para o formulário de busca de notícias
    document.getElementById('searchNews').addEventListener('submit', function(event) {
        event.preventDefault();
        var searchTerm = document.getElementById('searchInput').value.trim();

        if (searchTerm !== '') {
            fetchSearchResults(searchTerm, 'news'); // 'news' para pesquisa de notícias
        } else {
            alert('Por favor, digite um termo de busca para notícias.');
        }
    });

    // Event listener para o formulário de busca de livros
// Event listener para o formulário de busca de livros
document.getElementById('searchBooks').addEventListener('submit', function(event) {
    event.preventDefault();
    var searchTerm = document.getElementById('searchInput').value.trim();

    if (searchTerm !== '') {
        fetchSearchResults(searchTerm, 'shopping'); // 'books' para pesquisa de livros
    } else {
        alert('Por favor, digite um termo de busca para os produtos.');
    }
});

document.getElementById('searchPlaces').addEventListener('submit', function(event) {
    event.preventDefault();
    var searchTerm = document.getElementById('searchInput').value.trim();

    if (searchTerm !== '') {
        fetchSearchResults(searchTerm, 'places'); // 'books' para pesquisa de livros
    } else {
        alert('Por favor, digite um termo de busca para os lugares.');
    }
});

document.getElementById('searchScholar').addEventListener('submit', function(event) {
    event.preventDefault();
    var searchTerm = document.getElementById('searchInput').value.trim();

    if (searchTerm !== '') {
        fetchSearchResults(searchTerm, 'scholar'); // 'books' para pesquisa de livros
    } else {
        alert('Por favor, digite um termo de busca para os lugares.');
    }
});

document.getElementById('searchPatents').addEventListener('submit', function(event) {
    event.preventDefault();
    var searchTerm = document.getElementById('searchInput').value.trim();

    if (searchTerm !== '') {
        fetchSearchResults(searchTerm, 'patents'); // 'books' para pesquisa de livros
    } else {
        alert('Por favor, digite um termo de busca para os lugares.');
    }
});

document.getElementById('searchMap').addEventListener('submit', function(event) {
    event.preventDefault();
    var searchTerm = document.getElementById('searchInput').value.trim();

    if (searchTerm !== '') {
        fetchSearchResults(searchTerm, 'maps'); // 'books' para pesquisa de livros
    } else {
        alert('Por favor, digite um termo de busca para os lugares.');
    }
});


    // Função para exibir resultados de imagens
    function displayImageResults(data) {
        searchResultsElement.innerHTML = '';

        // Mostra resultados de imagens
        if (data.images && data.images.length > 0) {
            var images = data.images;
            var imageContainer = document.createElement('div');
            imageContainer.classList.add('image-container');

            images.forEach(image => {
                var imageElement = document.createElement('div');
                imageElement.classList.add('image-item');
                imageElement.innerHTML = `
                    <img src="${image.thumbnailUrl}" alt="${image.title}">
                    <p>${image.title}</p>
                    <a href="${image.link}" target="_blank">Ver no ${image.source}</a><br><br>
                `;
                imageContainer.appendChild(imageElement);
            });

            searchResultsElement.appendChild(imageContainer);
        } else {
            var noResultsMessage = document.createElement('p');
            noResultsMessage.textContent = 'Nenhum resultado encontrado para imagens.';
            searchResultsElement.appendChild(noResultsMessage);
        }
    }

    // Função para exibir resultados de notícias
    function displayNewsResults(data) {
        searchResultsElement.innerHTML = '';

        // Mostra resultados de notícias
        if (data.news && data.news.length > 0) {
            var news = data.news;
            var newsContainer = document.createElement('div');
            newsContainer.classList.add('news-container');

            news.forEach(article => {
                var newsElement = document.createElement('div');
                newsElement.classList.add('news-item');
                newsElement.innerHTML = `
                    <h3><a href="${article.link}" target="_blank">${article.title}</a></h3>
                    <p>${article.snippet}</p>
                    <p>${article.date}</p>
                    <p>Fonte: ${article.source}</p>
                    <img src="${article.imageUrl} alt="${article.title}">
                `;
                newsContainer.appendChild(newsElement);
            });

            searchResultsElement.appendChild(newsContainer);
        } else {
            var noResultsMessage = document.createElement('p');
            noResultsMessage.textContent = 'Nenhum resultado encontrado para notícias.';
            searchResultsElement.appendChild(noResultsMessage);
        }
    }

    // Função para exibir resultados de livros
    function displayBookResults(data) {
        searchResultsElement.innerHTML = '';
    
        if (data.shopping && data.shopping.length > 0) {
            var books = data.shopping;
            var bookContainer = document.createElement('div');
            bookContainer.classList.add('book-container'); // Adiciona a classe para o layout em grid
    
            books.forEach(book => {
                var bookElement = document.createElement('div');
                bookElement.classList.add('book-item'); // Adiciona a classe para o estilo do item de livro
                bookElement.innerHTML = `
                <a href="${book.link}" target="_blank">
                    <img src="${book.imageUrl}" alt="${book.title}"><br>
                    <h3>${book.title}</h3>
                </a><br>
                    <p>Site: ${book.source}</p>
                    <p>Preço: ${book.price}</p>
                `;
                bookContainer.appendChild(bookElement);
            });
    
            searchResultsElement.appendChild(bookContainer);
        } else {
            var noResultsMessage = document.createElement('p');
            noResultsMessage.textContent = 'Nenhum resultado encontrado para livros.';
            searchResultsElement.appendChild(noResultsMessage);
        }
    }
    

    // Função para exibir resultados de busca geral (sites)
    function displaySearchResults(data) {
        searchResultsElement.innerHTML = '';

        // Mostra o Knowledge Graph
        if (data.knowledgeGraph) {
            var knowledgeGraph = data.knowledgeGraph;
            var knowledgeGraphElement = document.createElement('div');
            knowledgeGraphElement.classList.add('knowledge-graph');
            knowledgeGraphElement.innerHTML = `
                <h2>${knowledgeGraph.title}</h2>
                <p><strong>Tipo:</strong> ${knowledgeGraph.type}</p>
                <p><strong>Website:</strong> <a href="${knowledgeGraph.website}" target="_blank">${knowledgeGraph.website}</a></p>
                <img src="${knowledgeGraph.imageUrl}" alt="${knowledgeGraph.title}" style="max-width: 200px; max-height: 200px;">
                <p>${knowledgeGraph.description} (<a href="${knowledgeGraph.descriptionLink}" target="_blank">fonte: ${knowledgeGraph.descriptionSource}</a>)</p>
                <h3>Atributos:</h3>
                <ul>
                    ${Object.keys(knowledgeGraph.attributes).map(key => `<li><strong>${key}:</strong> ${knowledgeGraph.attributes[key]}</li>`).join('')}
                </ul>
            `;
            searchResultsElement.appendChild(knowledgeGraphElement);
        }

        // Mostra os resultados orgânicos
        if (data.organic && data.organic.length > 0) {
            var organicResults = data.organic;
            organicResults.forEach(result => {
                var resultItem = document.createElement('div');
                resultItem.classList.add('result-item');
                resultItem.innerHTML = `
                    <h3><a href="${result.link}" target="_blank">${result.title}</a></h3>
                    <p>${result.snippet}</p>
                `;
                if (result.sitelinks && result.sitelinks.length > 0) {
                    resultItem.innerHTML += '<ul>';
                    result.sitelinks.forEach(sitelink => {
                        resultItem.innerHTML += `<li><a href="${sitelink.link}" target="_blank">${sitelink.title}</a></li>`;
                    });
                    resultItem.innerHTML += '</ul>';
                }
                searchResultsElement.appendChild(resultItem);
            });
        }

        // Mostra as pessoas também perguntam
        if (data.peopleAlsoAsk && data.peopleAlsoAsk.length > 0) {
            var peopleAlsoAsk = data.peopleAlsoAsk;
            var peopleAlsoAskElement = document.createElement('div');
            peopleAlsoAskElement.classList.add('related-searches');
            peopleAlsoAskElement.innerHTML = '<h2>Pessoas também perguntam:</h2>';
            peopleAlsoAsk.forEach(question => {
                peopleAlsoAskElement.innerHTML += `
                    <h3>${question.question}</h3>
                    <p>${question.snippet}</p>
                    <p><a href="${question.link}" target="_blank">${question.title}</a></p><br>
                `;
            });
            searchResultsElement.appendChild(peopleAlsoAskElement);
        }

        // Mostra as buscas relacionadas
        if (data.relatedSearches && data.relatedSearches.length > 0) {
            var relatedSearches = data.relatedSearches;
            var relatedSearchesElement = document.createElement('div');
            relatedSearchesElement.classList.add('related-searches');
            relatedSearchesElement.innerHTML = '<h2 id="related">Buscas relacionadas:</h2><ul>';
            relatedSearches.forEach(search => {
                relatedSearchesElement.innerHTML += `<li>${search.query}</li>`;
            });
            relatedSearchesElement.innerHTML += '</ul>';
            searchResultsElement.appendChild(relatedSearchesElement);

            // Após mostrar os resultados, exibir o menu de navegação
            navigation.style.display = 'block';
        }
    }

    function displayPlaces(data) {
        var placesResults = document.getElementById('searchResults');
        placesResults.innerHTML = ''; // Limpa resultados anteriores
  
        if (data && data.places) {
          var places = data.places;
          places.forEach(place => {
            var placeDiv = document.createElement('div');
            placeDiv.classList.add('place');
  
            var title = document.createElement('h2');
            title.textContent = place.title;
  
            var address = document.createElement('p');
            address.textContent = place.address;
  
            var category = document.createElement('p');
            category.textContent = 'Categoria: ' + place.category;
  
            var rating = document.createElement('p');
            rating.textContent = 'Nota: ' + place.rating + ' (baseado em ' + place.ratingCount + ' reviews)';
  
            var phoneNumber = document.createElement('p');
            phoneNumber.textContent = 'Contato: ' + place.phoneNumber;
  
            var websiteLink = document.createElement('a');
            websiteLink.textContent = 'Website';
            websiteLink.href = place.website;
            websiteLink.target = '_blank'; // Abre em nova aba
  
            placeDiv.appendChild(title);
            placeDiv.appendChild(address);
            placeDiv.appendChild(category);
            placeDiv.appendChild(rating);
            placeDiv.appendChild(phoneNumber);
            placeDiv.appendChild(websiteLink);
  
            placesResults.appendChild(placeDiv);
          });
        } else {
          placesResults.textContent = 'Nenhum lugar encontrado.';
        }
      }
      function displayScholar(data) {
        var resultsDiv = document.getElementById('searchResults');
        resultsDiv.innerHTML = ''; // Limpa resultados anteriores
      
        if (data && data.organic && data.organic.length > 0) {
          data.organic.forEach(item => {
            var resultItem = document.createElement('div');
            resultItem.classList.add('result-item');
      
            var title = document.createElement('h3');
            title.innerHTML = `<a href="${item.link}" target="_blank">${item.title}</a>`;
            resultItem.appendChild(title);
      
            var publicationInfo = document.createElement('p');
            publicationInfo.textContent = item.publicationInfo;
            resultItem.appendChild(publicationInfo);
      
            var snippet = document.createElement('p');
            snippet.textContent = item.snippet;
            resultItem.appendChild(snippet);
      
            resultsDiv.appendChild(resultItem);
          });
        } else {
          resultsDiv.innerHTML = '<p>Nenhum resultado encontrado.</p>';
        }
      }
      function displayPatents(results) {
        var resultsContainer = document.getElementById('searchResults');
        resultsContainer.innerHTML = ''; // Limpa os resultados anteriores
      
        results.organic.forEach(item => {
          var resultItem = document.createElement('div');
          resultItem.classList.add('resultItem');
          resultItem.innerHTML = `
            <h3><a href="${item.link}" target="_blank">${item.title}</a></h3>
            <p>${item.snippet}</p>
            <p><strong>Inventor:</strong> ${item.inventor}</p>
            <p><strong>Assignee:</strong> ${item.assignee}</p>
            <p><strong>Priority Date:</strong> ${item.priorityDate}</p>
            <p><strong>Filing Date:</strong> ${item.filingDate}</p>
            <p><strong>Publication Date:</strong> ${item.publicationDate}</p>
            <a href="${item.pdfUrl}" target="_blank">Ver PDF</a>
          `;
          resultsContainer.appendChild(resultItem);
        });
      }

      function displayMaps(results) {
        var resultList = document.getElementById('searchResults');
        resultList.innerHTML = '';
      
        results.places.forEach(place => {
          var li = document.createElement('li');
          
          var title = document.createElement('h2');
          title.textContent = place.title;
          li.appendChild(title);
          
          var address = document.createElement('p');
          address.textContent = place.address;
          li.appendChild(address);
          
          var rating = document.createElement('p');
          rating.textContent = `Avaliação: ${place.rating} (${place.ratingCount} reviews)`;
          li.appendChild(rating);
          
          var types = document.createElement('p');
          types.textContent = `Tipo: ${place.type}`;
          li.appendChild(types);
          
          var websiteLink = document.createElement('a');
          websiteLink.href = place.website;
          websiteLink.textContent = 'Visite o Website';
          websiteLink.setAttribute('target', '_blank');
          li.appendChild(websiteLink);
      
          if (place.thumbnailUrl) {
            var thumbnail = document.createElement('img');
            thumbnail.src = place.thumbnailUrl;
            thumbnail.alt = place.title;
            thumbnail.className = 'thumbnail';
            li.appendChild(thumbnail);
          }
      
          resultList.appendChild(li);
        });
      }
      
});

document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    const autocompleteResults = document.getElementById('autocomplete-results');
  
    let currentFocus = -1; // Controla o foco na sugestão
  
    searchInput.addEventListener('input', function() {
      const searchTerm = searchInput.value.trim();
  
      if (searchTerm.length === 0) {
        autocompleteResults.innerHTML = '';
        autocompleteResults.style.display = 'none';
        return;
      }
  
      const myHeaders = new Headers();
      myHeaders.append("X-API-KEY", "4c3d97b396c7f582018afb7f0801d93c85fc02fb");
      myHeaders.append("Content-Type", "application/json");
  
      const raw = JSON.stringify({
        "q": searchTerm,
        "type": "autocomplete",
        "engine": "google",
        "gl": "br",
        "hl": "pt",
        "num": 10
      });
  
      const requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow'
      };
  
      fetch("https://google.serper.dev/autocomplete", requestOptions)
        .then(response => response.json())
        .then(data => {
          const autocompleteItems = data.suggestions;
  
          if (autocompleteItems.length === 0) {
            autocompleteResults.innerHTML = '';
            autocompleteResults.style.display = 'none';
            return;
          }
  
          autocompleteResults.innerHTML = '';
  
          autocompleteItems.forEach((item, index) => {
            const li = document.createElement('li');
            li.textContent = item.value;
  
            li.addEventListener('click', function() {
              searchInput.value = item.value;
              autocompleteResults.innerHTML = '';
              autocompleteResults.style.display = 'none';
            });
  
            autocompleteResults.appendChild(li);
          });
  
          autocompleteResults.style.display = 'block';
          currentFocus = -1; // Reseta o foco ao mostrar novas sugestões
        })
        .catch(error => console.log('Error fetching autocomplete results:', error));
    });
  
    // Controle de navegação com o teclado
    searchInput.addEventListener('keydown', function(e) {
      const autocompleteItems = autocompleteResults.getElementsByTagName('li');
  
      if (autocompleteItems.length === 0) {
        return;
      }
  
      if (e.keyCode === 40) { // Tecla para baixo
        currentFocus++;
        addActive(autocompleteItems);
      } else if (e.keyCode === 38) { // Tecla para cima
        currentFocus--;
        addActive(autocompleteItems);
      } else if (e.keyCode === 13) { // Tecla Enter
        e.preventDefault();
        if (currentFocus > -1) {
          autocompleteItems[currentFocus].click();
        }
      }
    });
  
    function addActive(autocompleteItems) {
      // Remove a classe "active" de todos os itens da lista
      for (let i = 0; i < autocompleteItems.length; i++) {
        autocompleteItems[i].classList.remove('active');
      }
  
      if (currentFocus >= autocompleteItems.length) {
        currentFocus = 0;
      }
      if (currentFocus < 0) {
        currentFocus = autocompleteItems.length - 1;
      }
  
      // Adiciona a classe "active" ao item com foco atual
      autocompleteItems[currentFocus].classList.add('active');
  
      // Scroll automático para o item com foco
      autocompleteResults.scrollTop = autocompleteItems[currentFocus].offsetTop - autocompleteResults.offsetTop;
    }
  
    // Fecha a lista de sugestões ao clicar fora dela
    document.addEventListener('click', function(e) {
      if (!autocompleteResults.contains(e.target) && e.target !== searchInput) {
        autocompleteResults.innerHTML = '';
        autocompleteResults.style.display = 'none';
      }
    });
  });
  